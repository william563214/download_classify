import{e as c,f as r}from"../../storage.js";function o(e){switch(e){case"high":return"高";case"medium":return"中";default:return"低"}}function u(e){return`badge badge-${e}`}function p(e){const n=document.getElementById("stats-list");if(!n)return;const t=Object.entries(e);if(!t.length){n.innerHTML='<li class="empty">今日尚無下載紀錄</li>';return}n.innerHTML=t.map(([a,l])=>`<li><span>${i(a)}</span><span>${l}</span></li>`).join("")}function d(e){const n=document.getElementById("recent-list");if(n){if(!e.length){n.innerHTML='<li class="empty">尚無下載紀錄</li>';return}n.innerHTML=e.map(t=>{const a=t.imported?" · 歷史匯入":"";return`<li>
        <div class="filename">${i(t.filename)}</div>
        <div class="meta">
          ${i(t.category)} → ${i(t.target_folder)}
          · 來源 ${i(t.attributed_site||"-")}
          <span class="${u(t.attribution_confidence)}">${o(t.attribution_confidence)}</span>
          ${a}
        </div>
      </li>`}).join("")}}function i(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}async function m(){const[e,n]=await Promise.all([c(),r(20)]);p(e),d(n)}var s;(s=document.getElementById("open-options"))==null||s.addEventListener("click",e=>{e.preventDefault(),chrome.runtime.openOptionsPage()});m();
