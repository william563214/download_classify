import"../../modulepreload-polyfill.js";const I="modulepreload",w=function(e){return"/"+e},p={},L=function(n,t,i){let a=Promise.resolve();if(t&&t.length>0){let o=function(c){return Promise.all(c.map(m=>Promise.resolve(m).then(f=>({status:"fulfilled",value:f}),f=>({status:"rejected",reason:f}))))};document.getElementsByTagName("link");const s=document.querySelector("meta[property=csp-nonce]"),u=(s==null?void 0:s.nonce)||(s==null?void 0:s.getAttribute("nonce"));a=o(t.map(c=>{if(c=w(c),c in p)return;p[c]=!0;const m=c.endsWith(".css"),f=m?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${c}"]${f}`))return;const d=document.createElement("link");if(d.rel=m?"stylesheet":I,m||(d.as="script"),d.crossOrigin="",d.href=c,u&&d.setAttribute("nonce",u),document.head.appendChild(d),m)return new Promise(($,b)=>{d.addEventListener("load",$),d.addEventListener("error",()=>b(new Error(`Unable to preload CSS for ${c}`)))})}))}function l(o){const s=new Event("vite:preloadError",{cancelable:!0});if(s.payload=o,window.dispatchEvent(s),!s.defaultPrevented)throw o}return a.then(o=>{for(const s of o||[])s.status==="rejected"&&l(s.reason);return n().catch(l)})};function B(e){return e==="source"?"來源網站":e==="download"?"下載網站":"來源或下載網站"}function T(e){return B(e)}async function v(){return await chrome.runtime.sendMessage({type:"GET_CURRENT_SITE_STATUS"})}function _(e,n,t){return`<span class="status-badge ${e?"status-yes":"status-no"}">${e?n:t}</span>`}function g(e){const n=document.getElementById("site-classify-form");if(!n||e.unsupported_page){n==null||n.classList.add("hidden");return}n.classList.remove("hidden");const t=e.site_rule,i=document.getElementById("site-rule-name"),a=document.getElementById("site-rule-folder"),l=document.getElementById("site-rule-match-target"),o=document.getElementById("site-rule-id"),s=document.getElementById("site-rule-host");i.value=(t==null?void 0:t.name)??e.hostname,a.value=(t==null?void 0:t.target_folder)??e.fallback_folder,l.value=(t==null?void 0:t.match_target)??"source",o.value=(t==null?void 0:t.id)??"",s.value=e.hostname}function E(e){const n=document.getElementById("current-site-host"),t=document.getElementById("current-site-classification"),i=document.getElementById("current-site-attribution");if(!n||!t||!i)return;if(e.unsupported_page){n.textContent="無法分析此頁面",t.innerHTML='<p class="site-note">僅支援 http/https 網頁</p>',i.innerHTML="",g(e);return}const a=e.page_title?` · ${e.page_title}`:"";if(n.textContent=`${e.hostname}${a}`,e.classification_matches.length){const o=e.classification_matches.map(s=>{const u=s.kind==="site"?"網站分類":"自定義規則";return`<li>
          <span class="status-badge status-yes">已設定</span>
          <strong>${r(s.name)}</strong>
          <span class="site-meta">${r(u)} · ${r(T(s.match_role))}</span>
          <span class="site-folder">→ ${r(s.target_folder)}</span>
        </li>`}).join("");t.innerHTML=`
      <div class="site-status-title">目前規則</div>
      <ul class="site-status-list">${o}</ul>`}else t.innerHTML=`
      <div class="site-status-title">目前規則</div>
      <p class="site-line">
        ${_(!1,"","未設定")}
        <span class="site-meta">下載將暫存至 ${r(e.fallback_folder)}</span>
      </p>`;g(e);const l=[];e.link_trace_enabled&&l.push(`
      <li>
        ${_(!0,"點擊追蹤","")}
        <span class="site-meta">外連點擊會暫存，僅在歸因詢問站下載後可選為 A 站來源</span>
      </li>`),e.attribution_inquiry&&l.push(`
      <li>
        ${_(!0,"歸因詢問","")}
        <span class="site-meta">在此站下載完成後會詢問來源歸因</span>
      </li>`),e.known_file_host&&l.push(`
      <li>
        ${_(!0,"網盤站","")}
        <span class="site-meta">列為已知下載站，可被來源站追溯</span>
      </li>`),!e.attribution_inquiry&&!e.known_file_host&&l.push(`
      <li>
        ${_(!0,"當前頁歸因","")}
        <span class="site-meta">從此頁下載以當前網站為來源</span>
      </li>`),i.innerHTML=`
    <div class="site-status-title">歸因</div>
    <ul class="site-status-list">${l.join("")}</ul>`}async function S(e){e.preventDefault();const n=document.getElementById("site-save-status"),t=document.getElementById("site-rule-name").value,i=document.getElementById("site-rule-folder").value,a=document.getElementById("site-rule-match-target").value,l=document.getElementById("site-rule-id").value,o=document.getElementById("site-rule-host").value,s=await chrome.runtime.sendMessage({type:"SAVE_SITE_CLASSIFICATION",payload:{id:l||void 0,name:t,host:o,target_folder:i,match_target:a}});if(n&&(n.textContent=s.ok?"已儲存":s.error??"儲存失敗",n.className=s.ok?"site-save-status ok":"site-save-status error"),s.ok){const u=await v();E(u),setTimeout(()=>{n&&(n.textContent="")},2e3)}}async function k(){return await chrome.runtime.sendMessage({type:"GET_UNCLASSIFIED_DOWNLOADS"})}function P(e){switch(e){case"high":return"高";case"medium":return"中";default:return"低"}}function A(e){return`badge badge-${e}`}function C(e){const n=document.getElementById("stats-list");if(!n)return;const t=Object.entries(e);if(!t.length){n.innerHTML='<li class="empty">今日尚無下載紀錄</li>';return}n.innerHTML=t.map(([i,a])=>`<li><span>${r(i)}</span><span>${a}</span></li>`).join("")}function M(e){const n=document.getElementById("unclassified-section"),t=document.getElementById("unclassified-list");if(!(!n||!t)){if(!e.length){n.classList.add("hidden");return}n.classList.remove("hidden"),t.innerHTML=e.slice(0,10).map(i=>`
      <li class="unclassified-item">
        <div class="filename">${r(i.filename)}</div>
        <div class="meta">
          ${r(i.category)} → ${r(i.target_folder)}
          · 來源 ${r(i.attributed_site||"-")}
        </div>
        <button type="button" class="classify-btn" data-download-id="${i.download_id}">
          設定規則
        </button>
      </li>`).join(""),t.querySelectorAll(".classify-btn").forEach(i=>{i.addEventListener("click",()=>{const a=Number(i.dataset.downloadId);chrome.runtime.sendMessage({type:"OPEN_CLASSIFY_PROMPT",download_id:a})})})}}function H(e){const n=document.getElementById("recent-list");if(n){if(!e.length){n.innerHTML='<li class="empty">尚無下載紀錄</li>';return}n.innerHTML=e.map(t=>{const i=t.imported?" · 歷史匯入":"",a=t.is_unclassified?' <span class="badge badge-low">未分類</span>':"";return`<li>
        <div class="filename">${r(t.filename)}</div>
        <div class="meta">
          ${r(t.category)} → ${r(t.target_folder)}
          · 來源 ${r(t.attributed_site||"-")}
          <span class="${A(t.attribution_confidence)}">${P(t.attribution_confidence)}</span>
          ${a}
          ${i}
        </div>
      </li>`}).join("")}}function r(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}async function O(){const{get_recent_downloads:e,get_today_category_stats:n}=await L(async()=>{const{get_recent_downloads:o,get_today_category_stats:s}=await import("../../storage.js");return{get_recent_downloads:o,get_today_category_stats:s}},[]),[t,i,a,l]=await Promise.all([v(),n(),e(20),k()]);E(t),M(l),C(i),H(a)}var h;(h=document.getElementById("open-options"))==null||h.addEventListener("click",e=>{e.preventDefault(),chrome.runtime.openOptionsPage()});var y;(y=document.getElementById("site-classify-form"))==null||y.addEventListener("submit",e=>{S(e)});O();
