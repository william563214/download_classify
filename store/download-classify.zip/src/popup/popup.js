const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["storage.js","i18n.js"])))=>i.map(i=>d[i]);
import{t as s,a as L}from"../../i18n.js";const w="modulepreload",S=function(e){return"/"+e},g={},T=function(n,t,o){let l=Promise.resolve();if(t&&t.length>0){let c=function(u){return Promise.all(u.map(m=>Promise.resolve(m).then(f=>({status:"fulfilled",value:f}),f=>({status:"rejected",reason:f}))))};document.getElementsByTagName("link");const a=document.querySelector("meta[property=csp-nonce]"),p=(a==null?void 0:a.nonce)||(a==null?void 0:a.getAttribute("nonce"));l=c(t.map(u=>{if(u=S(u),u in g)return;g[u]=!0;const m=u.endsWith(".css"),f=m?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${u}"]${f}`))return;const d=document.createElement("link");if(d.rel=m?"stylesheet":w,m||(d.as="script"),d.crossOrigin="",d.href=u,p&&d.setAttribute("nonce",p),document.head.appendChild(d),m)return new Promise((b,I)=>{d.addEventListener("load",b),d.addEventListener("error",()=>I(new Error(`Unable to preload CSS for ${u}`)))})}))}function r(c){const a=new Event("vite:preloadError",{cancelable:!0});if(a.payload=c,window.dispatchEvent(a),!a.defaultPrevented)throw c}return l.then(c=>{for(const a of c||[])a.status==="rejected"&&r(a.reason);return n().catch(r)})};function B(e){return e==="source"?s("matchRoleSource"):e==="download"?s("matchRoleDownload"):s("matchRoleEither")}function C(e){return B(e)}async function $(){return await chrome.runtime.sendMessage({type:"GET_CURRENT_SITE_STATUS"})}function _(e,n,t){return`<span class="status-badge ${e?"status-yes":"status-no"}">${e?n:t}</span>`}function y(e){const n=document.getElementById("site-classify-form");if(!n||e.unsupported_page){n==null||n.classList.add("hidden");return}n.classList.remove("hidden");const t=e.site_rule,o=document.getElementById("site-rule-name"),l=document.getElementById("site-rule-folder"),r=document.getElementById("site-rule-match-target"),c=document.getElementById("site-rule-id"),a=document.getElementById("site-rule-host");o.value=(t==null?void 0:t.name)??e.hostname,l.value=(t==null?void 0:t.target_folder)??e.fallback_folder,r.value=(t==null?void 0:t.match_target)??"source",c.value=(t==null?void 0:t.id)??"",a.value=e.hostname}function E(e){const n=document.getElementById("current-site-host"),t=document.getElementById("current-site-classification"),o=document.getElementById("current-site-attribution");if(!n||!t||!o)return;if(e.unsupported_page){n.textContent=s("popupUnsupportedPage"),t.innerHTML=`<p class="site-note">${i(s("popupHttpsOnly"))}</p>`,o.innerHTML="",y(e);return}const l=e.page_title?` · ${e.page_title}`:"";if(n.textContent=`${e.hostname}${l}`,e.classification_matches.length){const c=e.classification_matches.map(a=>{const p=a.kind==="site"?s("popupKindSite"):s("popupKindCustom");return`<li>
          <span class="status-badge status-yes">${i(s("popupConfigured"))}</span>
          <strong>${i(a.name)}</strong>
          <span class="site-meta">${i(p)} · ${i(C(a.match_role))}</span>
          <span class="site-folder">→ ${i(a.target_folder)}</span>
        </li>`}).join("");t.innerHTML=`
      <div class="site-status-title">${i(s("popupCurrentRules"))}</div>
      <ul class="site-status-list">${c}</ul>`}else t.innerHTML=`
      <div class="site-status-title">${i(s("popupCurrentRules"))}</div>
      <p class="site-line">
        ${_(!1,"",s("popupNotConfigured"))}
        <span class="site-meta">${i(s("popupFallbackFolder",e.fallback_folder))}</span>
      </p>`;y(e);const r=[];e.link_trace_enabled&&r.push(`
      <li>
        ${_(!0,s("popupLinkTrace"),"")}
        <span class="site-meta">${i(s("popupLinkTraceHint"))}</span>
      </li>`),e.attribution_inquiry&&r.push(`
      <li>
        ${_(!0,s("popupAttrInquiry"),"")}
        <span class="site-meta">${i(s("popupAttrInquiryHint"))}</span>
      </li>`),e.known_file_host&&r.push(`
      <li>
        ${_(!0,s("popupFileHost"),"")}
        <span class="site-meta">${i(s("popupFileHostHint"))}</span>
      </li>`),!e.attribution_inquiry&&!e.known_file_host&&r.push(`
      <li>
        ${_(!0,s("popupCurrentPageAttr"),"")}
        <span class="site-meta">${i(s("popupCurrentPageAttrHint"))}</span>
      </li>`),o.innerHTML=`
    <div class="site-status-title">${i(s("popupAttrTitle"))}</div>
    <ul class="site-status-list">${r.join("")}</ul>`}async function k(e){e.preventDefault();const n=document.getElementById("site-save-status"),t=document.getElementById("site-rule-name").value,o=document.getElementById("site-rule-folder").value,l=document.getElementById("site-rule-match-target").value,r=document.getElementById("site-rule-id").value,c=document.getElementById("site-rule-host").value,a=await chrome.runtime.sendMessage({type:"SAVE_SITE_CLASSIFICATION",payload:{id:r||void 0,name:t,host:c,target_folder:o,match_target:l}});if(n&&(n.textContent=a.ok?s("popupSaved"):a.error??s("errorSaveFailed"),n.className=a.ok?"site-save-status ok":"site-save-status error"),a.ok){const p=await $();E(p),setTimeout(()=>{n&&(n.textContent="")},2e3)}}async function H(){return await chrome.runtime.sendMessage({type:"GET_UNCLASSIFIED_DOWNLOADS"})}function A(e){switch(e){case"high":return s("popupConfidenceHigh");case"medium":return s("popupConfidenceMedium");default:return s("popupConfidenceLow")}}function P(e){return`badge badge-${e}`}function M(e){const n=document.getElementById("stats-list");if(!n)return;const t=Object.entries(e);if(!t.length){n.innerHTML=`<li class="empty">${i(s("popupNoStatsToday"))}</li>`;return}n.innerHTML=t.map(([o,l])=>`<li><span>${i(o)}</span><span>${l}</span></li>`).join("")}function R(e){const n=document.getElementById("unclassified-section"),t=document.getElementById("unclassified-list");if(!(!n||!t)){if(!e.length){n.classList.add("hidden");return}n.classList.remove("hidden"),t.innerHTML=e.slice(0,10).map(o=>`
      <li class="unclassified-item">
        <div class="filename">${i(o.filename)}</div>
        <div class="meta">
          ${i(o.category)} → ${i(o.target_folder)}
          · ${i(s("popupSourceLabel",o.attributed_site||"-"))}
        </div>
        <button type="button" class="classify-btn" data-download-id="${o.download_id}">
          ${i(s("popupSetRule"))}
        </button>
      </li>`).join(""),t.querySelectorAll(".classify-btn").forEach(o=>{o.addEventListener("click",()=>{const l=Number(o.dataset.downloadId);chrome.runtime.sendMessage({type:"OPEN_CLASSIFY_PROMPT",download_id:l})})})}}function O(e){const n=document.getElementById("recent-list");if(n){if(!e.length){n.innerHTML=`<li class="empty">${i(s("popupNoRecent"))}</li>`;return}n.innerHTML=e.map(t=>{const o=t.imported?` · ${i(s("popupImported"))}`:"",l=t.is_unclassified?` <span class="badge badge-low">${i(s("popupUnclassifiedBadge"))}</span>`:"";return`<li>
        <div class="filename">${i(t.filename)}</div>
        <div class="meta">
          ${i(t.category)} → ${i(t.target_folder)}
          · ${i(s("popupSourceLabel",t.attributed_site||"-"))}
          <span class="${P(t.attribution_confidence)}">${A(t.attribution_confidence)}</span>
          ${l}
          ${o}
        </div>
      </li>`}).join("")}}function i(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}async function N(){L();const{get_recent_downloads:e,get_today_category_stats:n}=await T(async()=>{const{get_recent_downloads:c,get_today_category_stats:a}=await import("../../storage.js");return{get_recent_downloads:c,get_today_category_stats:a}},__vite__mapDeps([0,1])),[t,o,l,r]=await Promise.all([$(),n(),e(20),H()]);E(t),R(r),M(o),O(l)}var h;(h=document.getElementById("open-options"))==null||h.addEventListener("click",e=>{e.preventDefault(),chrome.runtime.openOptionsPage()});var v;(v=document.getElementById("site-classify-form"))==null||v.addEventListener("submit",e=>{k(e)});N();
